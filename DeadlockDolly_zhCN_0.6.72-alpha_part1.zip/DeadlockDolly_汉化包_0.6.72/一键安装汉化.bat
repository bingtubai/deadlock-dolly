@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONHASHSEED=0
title Deadlock Dolly - Chinese Patch
pushd "%~dp0"
tools\py312\python.exe tools\apply.py %*
echo.
pause
