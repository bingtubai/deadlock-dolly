# -*- coding: utf-8 -*-
"""给 Deadlock Dolly 的界面打上中文补丁（就地修改 exe，自动先备份）。

用法：
    python apply.py                自动查找 DeadlockDolly 目录
    python apply.py D:\\DeadlockDolly   手动指定
"""

import glob
import json
import marshal
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import common
from packer import CArchive, PYZ, map_strings

ZH_DIR = os.path.join(HERE, 'zh')


def load_mapping():
    mapping = {}
    for path in sorted(glob.glob(os.path.join(ZH_DIR, '*.json'))):
        with open(path, encoding='utf-8') as fh:
            mapping.update(json.load(fh))
    return mapping


def docstrings_of(co):
    out = set()
    seen = [co]
    while seen:
        c = seen.pop()
        if c.co_consts and isinstance(c.co_consts[0], str):
            out.add(c.co_consts[0])
        for k in c.co_consts:
            if isinstance(k, types.CodeType):
                seen.append(k)
    return out


def patch(exe, mapping):
    arch = CArchive(exe)
    pe = arch.pyz_entry()
    pyz = PYZ(arch.raw(pe))
    replacements = {}
    for name, (typ, pos, ln) in pyz.toc:
        if ln == 0 or not name.startswith('dolly'):
            continue
        co = pyz.module(name)
        if co is None:
            continue
        docs = docstrings_of(co)

        def fn(s, docs=docs):
            if s in docs:
                return s
            return mapping.get(s, s)

        new = map_strings(co, fn)
        if marshal.dumps(new) != marshal.dumps(co):
            replacements[name] = new
    return arch.rebuild(pyz.rebuild(replacements)), len(replacements)


def write_atomic(path, data):
    """写入目标文件；如果旧文件还在运行，就把它改名停放。"""
    tmp = path + '.new'
    with open(tmp, 'wb') as fh:
        fh.write(data)
    try:
        os.replace(tmp, path)
        return None
    except PermissionError:
        parked = path + '.old'
        if os.path.exists(parked):
            try:
                os.remove(parked)
            except OSError:
                parked = path + '.old%d' % os.getpid()
        os.rename(path, parked)
        os.rename(tmp, path)
        return parked


def main():
    print('=' * 56)
    print('  Deadlock Dolly  汉化补丁')
    print('=' * 56)
    print()

    mapping = load_mapping()
    target = common.get_target()
    print('Dolly 目录 : %s' % target)

    tver = common.target_version(target)
    pver = common.package_version()
    if tver:
        print('Dolly 版本 : %s' % tver)
    if tver and pver and tver != pver:
        print()
        print('提示：本补丁制作于 %s，你的版本是 %s。' % (pver, tver))
        print('      版本不同通常也能用（只会替换对得上的文案），')
        print('      但新版新增的文字可能仍是英文。')
    print('词条数量   : %d' % len(mapping))
    print()

    made, bdir = common.backup_if_needed(target)
    if made:
        print('已备份英文原版 -> %s' % bdir)
        for f in made:
            print('    %s' % f)
    else:
        print('英文原版备份已存在（或文件已是汉化版），未重复备份。')
    print()

    failed = []
    for rel, flat in common.TARGETS:
        exe = os.path.join(target, rel)
        if not os.path.isfile(exe):
            print('  跳过 %-20s （没找到）' % flat)
            continue
        out, n = patch(exe, mapping)
        with open(exe, 'rb') as fh:
            original = fh.read()
        if out == original:
            print('  %-20s 已是汉化版，无需修改' % flat)
            continue
        try:
            parked = write_atomic(exe, out)
        except OSError as exc:
            failed.append(flat)
            print('  %-20s 写入失败：%s' % (flat, exc))
            continue
        print('  %-20s 完成，汉化 %d 个模块' % (flat, n))
        if parked:
            print('  %-20s 注意：旧文件正在运行，已改名停在 %s'
                  % ('', os.path.basename(parked)))

    # 旧影像如果已经不被占用，顺手清掉
    stale = []
    for rel, flat in common.TARGETS:
        parked = os.path.join(target, rel) + '.old'
        if not os.path.exists(parked):
            continue
        try:
            os.remove(parked)
        except OSError:
            stale.append(os.path.basename(parked))

    print()
    common.report_auto_updates(*common.disable_auto_updates())
    print()

    if failed:
        print('有 %d 个文件没能写入：%s' % (len(failed), '、'.join(failed)))
        print('请先完全关闭 Dolly（任务栏里也确认退出），再运行一次。')
        sys.exit(2)

    if stale:
        print('提示：%s 还在被占用，关闭 Dolly 后可以手动删除（不影响使用）。'
              % '、'.join(stale))
        print()

    print('完成！重新打开 Dolly.exe 就是中文界面了。')
    print('想还原英文：运行 tools\\还原英文原版.bat')


if __name__ == '__main__':
    main()
