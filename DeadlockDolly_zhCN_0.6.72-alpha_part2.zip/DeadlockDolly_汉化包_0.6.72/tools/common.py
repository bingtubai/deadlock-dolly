# -*- coding: utf-8 -*-
"""公共逻辑：定位 DeadlockDolly 目录、备份原版、关闭自动更新。"""

import json
import os
import shutil
import string
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_ROOT = os.path.dirname(HERE)

# 相对 Dolly 根目录的路径 -> 备份时的扁平文件名
TARGETS = (
    ('Dolly.exe', 'Dolly.exe'),
    (os.path.join('_internal', 'DollyApp.exe'), 'DollyApp.exe'),
)
BACKUP_DIRNAME = '_backup_original'
PATCHED_DIRNAME = '已汉化的程序文件'


# ---------------------------------------------------------------- 目录探测

def looks_like_dolly(path):
    return (os.path.isfile(os.path.join(path, 'Dolly.exe'))
            and os.path.isfile(os.path.join(path, '_internal', 'DollyApp.exe')))


def _candidates():
    # 1) 命令行参数（可以直接把文件夹拖到 bat 上）
    for a in sys.argv[1:]:
        a = a.strip().strip('"').strip("'").strip()
        if a:
            yield a
            yield a.rstrip('\\/')
    # 2) 环境变量
    env = os.environ.get('DOLLY_DIR')
    if env:
        yield env
    # 3) 分享包被解压进 Dolly 目录里的情况
    yield os.path.dirname(PKG_ROOT)
    # 4) 常见位置
    for drv in string.ascii_uppercase:
        root = drv + ':/'
        if not os.path.exists(root):
            continue
        yield root + 'DeadlockDolly'
        for mid in ('Games', 'Game', 'games', 'game', 'Download', 'Downloads',
                    '下载', '游戏', 'PC Games', 'DeadlockDolly'):
            yield root + mid + '/DeadlockDolly'


def find_target():
    seen = set()
    for c in _candidates():
        try:
            c = os.path.abspath(c)
        except Exception:
            continue
        if c in seen:
            continue
        seen.add(c)
        if looks_like_dolly(c):
            return c
    return None


def ask_target():
    print('没有自动找到 DeadlockDolly 文件夹。')
    print('请把 DeadlockDolly 文件夹（里面有 Dolly.exe 和 _internal 的那个）')
    try:
        raw = input('拖到本窗口，然后按回车：')
    except (EOFError, KeyboardInterrupt):
        return None
    raw = raw.strip().strip('"').strip("'").strip()
    if not raw:
        return None
    path = os.path.abspath(raw)
    if looks_like_dolly(path):
        return path
    print('这个文件夹里没有同时找到 Dolly.exe 和 _internal\\DollyApp.exe，已取消。')
    return None


def get_target():
    target = find_target()
    if target:
        return target
    target = ask_target()
    if not target:
        print('\n已取消，没有做任何改动。')
        sys.exit(1)
    return target


# ---------------------------------------------------------------- 版本信息

def package_version():
    try:
        with open(os.path.join(HERE, 'version.json'), encoding='utf-8') as fh:
            return json.load(fh).get('version')
    except Exception:
        return None


def target_version(target):
    try:
        with open(os.path.join(target, 'BUILD_INFO.json'), encoding='utf-8') as fh:
            return json.load(fh).get('version')
    except Exception:
        return None


# ---------------------------------------------------------------- 判断是否已汉化

def _has_cjk(co):
    stack = [co]
    while stack:
        c = stack.pop()
        for k in c.co_consts:
            if isinstance(k, types.CodeType):
                stack.append(k)
            elif isinstance(k, str):
                if any('\u4e00' <= ch <= '\u9fff' for ch in k):
                    return True
            elif isinstance(k, (tuple, list, frozenset)):
                inner = [k]
                while inner:
                    x = inner.pop()
                    if isinstance(x, str):
                        if any('\u4e00' <= ch <= '\u9fff' for ch in x):
                            return True
                    elif isinstance(x, (tuple, list, frozenset)):
                        inner.extend(x)
    return False


# 常见含界面文案的模块(任一 exe 命中即可判为已汉化)
PATCH_PROBE_MODULES = (
    'dolly.gui', 'dolly.editor_actions', 'dolly.ui.settings_page',
    'dolly.ui_theme', 'dolly.updater', 'dolly.update_worker',
    'dolly.runtime', 'dolly.release_launcher', 'dolly.controller',
    'dolly.editor_dispatch',
)


def is_patched(exe):
    """exe 里是否已经含中文界面文案。

    先探测常见界面模块; 都不命中时再全量扫描所有 dolly 模块,
    避免 Dolly.exe(启动器, 只有少量模块)被漏判而导致
    重复打补丁时把英文备份覆盖成汉化版。
    """
    try:
        from packer import CArchive, PYZ
        arch = CArchive(exe)
        pyz = PYZ(arch.raw(arch.pyz_entry()))
        for name in PATCH_PROBE_MODULES:
            try:
                co = pyz.module(name)
            except KeyError:
                continue
            if co is not None and _has_cjk(co):
                return True
        for name, (typ, pos, ln) in pyz.toc:
            if ln == 0 or not name.startswith('dolly'):
                continue
            co = pyz.module(name)
            if co is not None and _has_cjk(co):
                return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------- 备份

def backup_if_needed(target):
    """把仍是英文原版的 exe 备份到 _backup_original\\。

    已经是汉化版的文件不会被拿去覆盖英文备份。
    """
    bdir = os.path.join(target, BACKUP_DIRNAME)
    made = []
    for rel, flat in TARGETS:
        src = os.path.join(target, rel)
        if not os.path.isfile(src):
            continue
        if is_patched(src):
            continue
        os.makedirs(bdir, exist_ok=True)
        shutil.copy2(src, os.path.join(bdir, flat))
        made.append(flat)
    return made, bdir


# ---------------------------------------------------------------- 自动更新

def disable_auto_updates():
    """把 %APPDATA%\\DeadlockDolly\\settings.json 的 auto_updates 改成 false。

    返回 (状态, 说明)。状态取值：done / already / absent / skipped / error
    """
    appdata = os.environ.get('APPDATA')
    if not appdata:
        return 'skipped', '找不到 APPDATA 环境变量'
    path = os.path.join(appdata, 'DeadlockDolly', 'settings.json')
    if not os.path.exists(path):
        return 'absent', path
    try:
        with open(path, encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or 'auto_updates' not in data:
            return 'skipped', path
        if data.get('auto_updates') is False:
            return 'already', path
        shutil.copy2(path, path + '.bak')
        data['auto_updates'] = False
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        return 'done', path
    except Exception as exc:
        return 'error', '%s（%s）' % (path, exc)


def report_auto_updates(status, info):
    if status == 'done':
        print('已关闭自动更新（%s）' % info)
    elif status == 'already':
        print('自动更新本来就是关闭的。')
    elif status == 'absent':
        print('还没生成过设置文件，跳过自动更新设置。')
        print('  首次打开 Dolly 后，建议在「设置」里把自动更新关掉，否则更新后汉化会失效。')
    elif status == 'skipped':
        print('没有识别到设置文件里的自动更新项，未改动：%s' % info)
    else:
        print('设置自动更新时出错（不影响汉化）：%s' % info)
