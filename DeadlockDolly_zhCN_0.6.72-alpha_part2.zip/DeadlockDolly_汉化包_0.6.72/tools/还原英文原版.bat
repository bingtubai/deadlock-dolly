@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONHASHSEED=0
title Deadlock Dolly - Restore English
pushd "%~dp0"
py312\python.exe restore.py %*
echo.
pause
