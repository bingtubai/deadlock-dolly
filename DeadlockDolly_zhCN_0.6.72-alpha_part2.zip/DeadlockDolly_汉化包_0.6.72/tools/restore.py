# -*- coding: utf-8 -*-
"""把 Deadlock Dolly 还原成英文原版（从 _backup_original 恢复）。"""

import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import common


def main():
    print('=' * 56)
    print('  Deadlock Dolly  还原英文原版')
    print('=' * 56)
    print()

    target = common.get_target()
    bdir = os.path.join(target, common.BACKUP_DIRNAME)
    print('Dolly 目录 : %s' % target)
    print('备份目录   : %s' % bdir)
    print()

    if not os.path.isdir(bdir):
        print('没有找到备份目录，无法还原。')
        print('（只有运行过汉化补丁并备份过的目录才有这个文件夹）')
        sys.exit(1)

    done = 0
    failed = []
    for rel, flat in common.TARGETS:
        src = os.path.join(bdir, flat)
        dst = os.path.join(target, rel)
        if not os.path.isfile(src):
            print('  跳过 %-20s （备份里没有）' % flat)
            continue
        try:
            if os.path.isfile(dst):
                tmp = dst + '.new'
                shutil.copy2(src, tmp)
                os.replace(tmp, dst)
            else:
                shutil.copy2(src, dst)
        except OSError as exc:
            failed.append(flat)
            print('  失败 %-20s %s' % (flat, exc))
            continue
        print('  已还原 %s' % flat)
        done += 1

    print()
    if failed:
        print('有文件没能还原，请先关闭 Dolly 再试一次。')
        sys.exit(2)
    print('已还原 %d 个文件，Dolly 回到英文原版。' % done)


if __name__ == '__main__':
    main()
