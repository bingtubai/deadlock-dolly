@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONHASHSEED=0
title Deadlock Dolly - Re-apply Chinese Patch
pushd "%~dp0"
py312\python.exe apply.py %*
echo.
pause
