"""Deadlock Dolly PyInstaller patcher.

Reads a PyInstaller onefile/onepackage executable, rewrites string constants in
the .pyc modules stored inside its PYZ archive, and rebuilds a valid executable.

Verified with a no-op rebuild: rebuilding without any modification reproduces
the original file byte for byte.
"""

import marshal
import struct
import types
import zlib

C_MAGIC = b'MEI\x0c\x0b\x0a\x0b\x0e'
COOKIE_FMT = '!8sIIii64s'
COOKIE_SIZE = struct.calcsize(COOKIE_FMT)      # 88
ENTRY_FMT = '!iIIIBc'
ENTRY_HEAD = struct.calcsize(ENTRY_FMT)        # 18


class CArchive:
    """PyInstaller CArchive (the archive glued to the end of the exe)."""

    def __init__(self, path):
        self.path = path
        with open(path, 'rb') as fh:
            self.data = fh.read()
        pos = self.data.rfind(C_MAGIC)
        if pos < 0:
            raise ValueError('not a PyInstaller archive: %s' % path)
        (self.magic, self.lenpkg, self.toc_off, self.toc_len,
         self.pyvers, self.pylib) = struct.unpack(
            COOKIE_FMT, self.data[pos:pos + COOKIE_SIZE])
        self.pkgstart = len(self.data) - self.lenpkg
        self.stub = self.data[:self.pkgstart]
        self.entries = []
        p = self.pkgstart + self.toc_off
        end = p + self.toc_len
        while p < end:
            entlen, dpos, dlen, ulen, flag, typ = struct.unpack(
                ENTRY_FMT, self.data[p:p + ENTRY_HEAD])
            raw = self.data[p:p + entlen]
            name = raw[ENTRY_HEAD:].rstrip(b'\x00').decode('utf-8')
            self.entries.append({
                'name': name, 'typ': typ.decode('latin1'), 'dpos': dpos,
                'dlen': dlen, 'ulen': ulen, 'flag': flag, 'entlen': entlen,
                'namebytes': raw[ENTRY_HEAD:],
            })
            p += entlen

    def raw(self, e):
        """Stored bytes of an entry (compressed if flag says so)."""
        return self.data[self.pkgstart + e['dpos']:
                         self.pkgstart + e['dpos'] + e['dlen']]

    def pyz_entry(self):
        for e in self.entries:
            if e['typ'] == 'z':
                return e
        raise KeyError('no PYZ entry')

    def rebuild(self, new_pyz_blob):
        """Rebuild the whole package, swapping in a new PYZ blob."""
        pe = self.pyz_entry()
        body = bytearray()
        toc = bytearray()
        for e in self.entries:
            if e is pe:
                payload = new_pyz_blob
                dlen = ulen = len(payload)
                flag = 0
            else:
                payload = self.raw(e)
                dlen, ulen, flag = e['dlen'], e['ulen'], e['flag']
            dpos = len(body)
            body += payload
            toc += struct.pack(ENTRY_FMT, e['entlen'], dpos, dlen, ulen,
                               flag, e['typ'].encode('latin1')) + e['namebytes']
        lenpkg = len(body) + len(toc) + COOKIE_SIZE
        cookie = struct.pack(COOKIE_FMT, self.magic, lenpkg, len(body),
                             len(toc), self.pyvers, self.pylib)
        return bytes(self.stub) + bytes(body) + bytes(toc) + cookie


class PYZ:
    """PyInstaller ZlibArchive holding the marshalled modules."""

    def __init__(self, blob):
        self.blob = blob
        if blob[:4] != b'PYZ\0':
            raise ValueError('bad PYZ magic')
        self.tocpos = struct.unpack('!I', blob[8:12])[0]
        self.header = blob[:17]
        self.toc = marshal.loads(blob[self.tocpos:])

    def module(self, name):
        for n, (typ, pos, ln) in self.toc:
            if n == name:
                if ln == 0:
                    return None
                return marshal.loads(zlib.decompress(self.blob[pos:pos + ln]))
        raise KeyError(name)

    def rebuild(self, replacements):
        """replacements: {module name: marshalled bytes or code object}."""
        out = bytearray(self.header)
        newtoc = []
        for name, (typ, pos, ln) in self.toc:
            if ln == 0:
                newtoc.append((name, (typ, pos, ln)))
                continue
            if name in replacements:
                obj = replacements[name]
                raw = obj if isinstance(obj, bytes) else marshal.dumps(obj)
                payload = zlib.compress(raw, 9)
            else:
                payload = self.blob[pos:pos + ln]
            newpos = len(out)
            out += payload
            newtoc.append((name, (typ, newpos, len(payload))))
        tocpos = len(out)
        out += marshal.dumps(newtoc)
        struct.pack_into('!I', out, 8, tocpos)
        return bytes(out)


def _map_const(k, fn):
    """Apply fn to a constant, descending into containers.

    String tables such as ('capture', 'Capture camera') live inside tuple
    constants, so a walker that only looks at plain strings misses them.
    """
    if isinstance(k, types.CodeType):
        return _map_code(k, fn)
    if isinstance(k, str):
        return fn(k)
    if isinstance(k, tuple):
        new = tuple(_map_const(x, fn) for x in k)
        return k if new == k else new
    if isinstance(k, frozenset):
        new = frozenset(_map_const(x, fn) for x in k)
        return k if new == k else new
    if isinstance(k, list):
        new = [_map_const(x, fn) for x in k]
        return k if new == k else new
    return k


def _map_code(c, fn):
    new_consts = tuple(_map_const(k, fn) for k in c.co_consts)
    if new_consts == c.co_consts:
        return c
    return types.CodeType(
        c.co_argcount, c.co_posonlyargcount, c.co_kwonlyargcount,
        c.co_nlocals, c.co_stacksize, c.co_flags, c.co_code, new_consts,
        c.co_names, c.co_varnames, c.co_filename, c.co_name,
        c.co_qualname, c.co_firstlineno, c.co_linetable,
        c.co_exceptiontable, c.co_freevars, c.co_cellvars)


def walk_strings(co):
    """Yield every string constant in a code object tree."""
    seen = [co]
    while seen:
        c = seen.pop()
        for k in c.co_consts:
            if isinstance(k, types.CodeType):
                seen.append(k)
            elif isinstance(k, str):
                yield k
            elif isinstance(k, (tuple, frozenset, list)):
                stack = [k]
                while stack:
                    x = stack.pop()
                    if isinstance(x, str):
                        yield x
                    elif isinstance(x, (tuple, frozenset, list)):
                        stack.extend(x)


def map_strings(co, fn):
    """Rebuild a code object with every string constant passed through fn."""
    return _map_code(co, fn)
